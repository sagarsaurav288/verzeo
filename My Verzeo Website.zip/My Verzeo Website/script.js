     setTimeout(function(){
		$('.loaderhome').fadeToggle();
	 },300);
	 
	 window.addEventListener("scroll", function(){
	 var header = document.querySelector("header");
	 header.classList.toggle("sticky", window.scrollY);
	
	})
	 function toggle(){
		 var header = document.querySelector("header");
		 header.classList.toggle("active");
	 }
	function prompty(){
		window.alert("Thats all about me and scroll down to avail my services");
	}
	function alertbox(){
		window.alert("If u want to look at some sample services, then do contact me at +917377270431");
	}
	function cv(){
		window.open("SagarBehera Resume.pdf");
	}
	
	$(document).ready(function(){
	
	$("#submit1").click(function(){
		$.ajax({
			url: "https://reqres.in/api/users",
			type: "POST",
			data: {
				  name: $("#name1").val()
			},
			success: function(response){
				console.log(response);
		    window.alert("Thank You" + " " + response.name + ". Soon we will contact you .");
		
		
	}
	
	
});	
});	
	
	
	
	});	